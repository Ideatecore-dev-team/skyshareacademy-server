const app = require("./src/api/app");

app.listen(3000, () => {
  console.log("app listening on port 3000!");
});
